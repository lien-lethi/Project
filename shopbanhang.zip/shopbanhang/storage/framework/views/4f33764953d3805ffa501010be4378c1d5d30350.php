<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E-Shopper</title>
    <link href="<?php echo e(asset('public/frontent/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/frontent/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/frontent/css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/frontent/css/price-range.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/frontent/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/frontent/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/frontent/css/responsive.css')); ?>" rel="stylesheet">

        <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
        <link rel="stylesheet" href="css/fontawesome-stars.css">
        <link rel="stylesheet" href="css/meanmenu.css">
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/slick.css">
        <link rel="stylesheet" href="css/jquery-ui.min.css">
        <link rel="stylesheet" href="css/venobox.css">
        <link rel="stylesheet" href="css/nice-select.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/helper.css">
        <link rel="stylesheet" href="style.css">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="public/frontent/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
    <header id="header"><!--header-->
        <div class="header_top"><!--header_top-->
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="contactinfo">
                            <ul class="nav nav-pills">
                                <li><a href="#"><i class="fa fa-phone"></i> 0973742895</a></li>
                                <li><a href="#"><i class="fa fa-envelope"></i> lephuonglien10@gmail.com</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="social-icons pull-right">
                            <ul class="nav navbar-nav">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/header_top-->
        
        <div class="header-middle"><!--header-middle-->
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="logo pull-left">
                            <a href="welcome.blade.php"><img src="<?php echo e(URL::to('public/frontent/images/logo.png')); ?>" alt="" /></a>
                        </div>
                        <div class="btn-group pull-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
                                    Việt Nam
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a href="#">VietNam</a></li>
                                    <li><a href="#">UK</a></li>
                                </ul>
                            </div>
                            
                            <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
                                    VN
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a href="#">VN</a></li>
                                    <li><a href="#">$</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="shop-menu pull-right">
                            <ul class="nav navbar-nav">
                                
                                <li><a href="#"><i class="fa fa-star"></i> Yêu thích</a></li>
                                <?php
                                $customer_id = Session::get('customer_id');
                                $shipping_id = Session::get('shipping_id');
                                if($customer_id!=NULL && $shipping_id == NULL){
                                ?>
                               <li><a href="<?php echo e(URL::to('/checkout')); ?>"><i class="fa fa-crosshairs"></i> Thanh toán</a></li>
                                <?php
                            }elseif($customer_id!=NULL && $shipping_id!=NULL){
                                ?>
                            <li><a href="<?php echo e(URL::to('/payment')); ?>"><i class="fa fa-crosshairs"></i> Thanh toán</a></li>
                            <?php
                            }else{
                                ?>
                            <li><a href="<?php echo e(URL::to('/login-checkout')); ?>"><i class="fa fa-crosshairs"></i> Thanh toán</a></li>
                                <?php
                            }
                                ?>  
                                <li><a href="<?php echo e(URL::to('/show-cart')); ?>"><i class="fa fa-shopping-cart"></i>Giỏ hàng</a></li>
                                <?php
                                $customer_id = Session::get('customer_id');
                                if($customer_id!=NULL){
                                ?>
                                <li><a href="<?php echo e(URL::to('/logout-checkout')); ?>"><i class="fa fa-lock"></i> Đăng xuất</a></li>
                                <?php
                            }else{
                                ?>
                                <li><a href="<?php echo e(URL::to('/login-checkout')); ?>"><i class="fa fa-lock"></i> Đăng nhập</a></li>
                                <?php
                            }
                                ?>  
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/header-middle-->
    
        <div class="header-bottom"><!--header-bottom-->
            <div class="container">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="mainmenu pull-left">
                            <ul class="nav navbar-nav collapse navbar-collapse">
                                <li><a href="<?php echo e(URL::to('/trang-chu')); ?>" class="active">Trang chủ</a></li>
                                <li class="dropdown"><a href="#">shop<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="shop.html">Sản phẩm</a></li>
                                        <li><a href="product-details.html">Chi tiết sản phẩm</a></li> 
                                        <li><a href="checkout.html">Thanh toán</a></li> 
                                        <li><a href="<?php echo e(URL::to('/show-cart')); ?>">Giỏ hàng</a></li> 
                                        <li><a href="login.html">Đăng nhập</a></li> 
                                    </ul>
                                </li> 
                                <li class="dropdown"><a href="#">Tin tức<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="blog.html">Danh sách tin tức</a></li>
                                    
                                    </ul>
                                </li> 
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <form action="<?php echo e(URL::to('/tim-kiem')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                        <div class="search_box pull-right">
                            <input type="text" name="keywords_submit" placeholder="Tìm kiếm sản phẩm"/>
                            <input type="submit" style="margin-top: 0;color: #000" name="search_items" class="btn btn-primary btn-sm" value="Tìm kiếm">
                        </div>
                       </form>
                    </div>
                </div>
            </div>
        </div><!--/header-bottom-->
    </header><!--/header-->
    
    <section id="slider"><!--slider-->
        <div class="container">
            <div class="row">
               <!-- <div class="col-lg-3">
                            
                            <div class="li-banner">
                                <a href="#">
                                    <img src="public/frontent/images/banner/featured-banner.jpg" alt="">
                                </a>
                            </div>

                </div>-->
                        <!-- Category Menu Area End Here -->
                        <!-- Begin Slider Area -->
                        <div class="col-md-9">
                            <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
                            <li data-target="#slider-carousel" data-slide-to="1"></li>
                            <li data-target="#slider-carousel" data-slide-to="2"></li>
                        </ol>
                        
                        <div class="carousel-inner">

                            <div class="item active">
                                <div class="col-sm-6">
                                    <h1><span>E</span>-SHOPPER</h1>
                                    <h2>Free E-Commerce Template</h2>
                                    
                                    <button type="button" class="btn btn-default get">Get it now</button>
                                </div>
                                <div class="col-sm-6">
                                   
                                   <img src="<?php echo e(URL::to('public/frontent/images/tivi2.jpg')); ?>" class="girl img-responsive" alt="" />
                                   <img src="<?php echo e(URL::to('public/frontent/images/nentrang.jpg')); ?>" class="girl img-responsive" alt="" />
                                   <!--<img src="public/frontent/images/tivi2.jpg"  class="pricing" alt="" />-->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-sm-6">
                                    <h1><span>E</span>-SHOPPER</h1>
                                    <h2>100% Responsive Design</h2>
                                    
                                    <button type="button" class="btn btn-default get">Get it now</button>
                                </div>
                                <div class="col-sm-6">
                                    <img src="<?php echo e(URL::to('public/frontent/images/thinkpad.jpg')); ?>" class="girl img-responsive" alt="" />
                                    <img src="<?php echo e(URL::to('public/frontent/images/nentrang8.jpg')); ?>" class="girl img-responsive" alt="" />
                                    <!--<img src="public/frontent/images/pricing.png"  class="pricing" alt="" />-->
                                </div>
                            </div>
                            
                            
                            <div class="item">
                                <div class="col-sm-6">
                                    <h1><span>E</span>-SHOPPER</h1>
                                    <h2>Free Ecommerce Template</h2>
                                    
                                    <button type="button" class="btn btn-default get">Get it now</button>
                                </div>
                                <div class="col-sm-6">
                                    <img src="<?php echo e(URL::to('public/frontent/images/iphoneSE1.png')); ?>" class="girl img-responsive" alt="" />
                                    <img src="<?php echo e(URL::to('public/frontent/images/nentrang8.jpg')); ?>" class="girl img-responsive" alt="" />
                                    <!--<img src="public/frontent/images/pricing.png" class="pricing" alt="" />-->
                                </div>
                            </div>
                            
                        </div>
                        
                        <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </>
                            </div>
                        </div>
                        <!-- Slider Area End Here -->
                        <!-- Begin Li Banner Area -->
                        <div class="col-lg-3 col-md-4 text-center pt-sm-30">
                            <div class="li-banner">
                                <a href="#">
                                    <img src="<?php echo e(URL::to('public/frontent/images/featured-banner.jpg')); ?>" alt="">
                                </a>
                            </div>
                            <!--<div class="li-banner mt-15 mt-sm-30 mt-xs-25 mb-xs-5">
                                <a href="#">
                                    <img src="public/frontent/images/banner/3_2.jpg" alt="">
                                </a>
                            </div>-->
                        </div>

                         <div class="li-static-banner li-static-banner-3 text-center">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="static-top-content mt-sm-30">
                                
                                <a href="#">
                                    
                                    <img src="<?php echo e(URL::to('public/frontent/images/banner/123.jpg')); ?>" style="width: 500;" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="container">
                    <div class="row">
                        <!-- Begin Li's Section Area -->
                        <div class="col-lg-12">
                            <div class="li-banner-2 pt-15">
                                <div class="row">
                                    <!-- Begin Single Banner Area -->
                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-banner">
                                            <a href="#">
                                                <img src="<?php echo e(URL::to('public/frontent/images/2_1.jpg')); ?>" alt="Li's Static Banner">
                                            </a>
                                        </div>
                                    </div>
                                    <!-- Single Banner Area End Here -->
                                    <!-- Begin Single Banner Area -->
                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-banner pt-xs-30">
                                            <a href="#">
                                                <img src="<?php echo e(URL::to('public/frontent/images/2_5.jpg')); ?>" alt="Li's Static Banner">
                                            </a>
                                        </div>
                                    </div>
                                    <!-- Single Banner Area End Here -->
                                </div>
                            </div>
                            </div>
                        <!-- Li's Section Area End Here -->
                    </div>
                </div>
            
            </div>
            </div>
        </div>
    </section><!--/slider-->

    

    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar">
                        <h2>Danh mục sản phẩm</h2>
                        <div class="panel-group category-products" id="accordian"><!--category-productsr-->
                          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title"><a href="<?php echo e(URL::to('/danh-muc-san-pham/'.$cate->category_id)); ?>"><?php echo e($cate->category_name); ?></a></h4>
                                </div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!--/category-products-->
                    
                        <div class="brands_products"><!--brands_products-->
                            <h2>Thương hiệu sản phẩm</h2>
                            <div class="brands-name">
                                <ul class="nav nav-pills nav-stacked">
                                     <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(URL::to('/thuong-hieu-san-pham/'.$brand->brand_id)); ?>"> <span class="pull-right"></span><?php echo e($brand->brand_name); ?></a></li>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </ul>
                            </div>
                        </div><!--/brands_products-->
                        
                        <div class="price-range"><!--price-range-->
                            <h2>Price Range</h2>
                            <div class="well text-center">
                                 <input type="text" class="span2" value="" data-slider-min="0" data-slider-max="600" data-slider-step="5" data-slider-value="[250,450]" id="sl2" ><br />
                                 <b class="pull-left"> 0đ</b> <b class="pull-right">30.000.000đ</b>
                            </div>
                        </div><!--/price-range-->
                        
                        <div class="shipping text-center"><!--shipping-->
                            <img src="<?php echo e(URL::to('public/frontent/images/banner_left.jpg')); ?>" class="girl img-responsive" alt="" />
                        </div><!--/shipping-->
                    
                    </div>
                </div>
                
                <div class="col-sm-9 padding-right">
                  <?php echo $__env->yieldContent('content'); ?>
                    
                 
                </div>
            </div>
        </div>
    </section>
    <div class="li-static-banner">
                <div class="container">
                    <div class="row">
                        <!-- Begin Single Banner Area -->
                        <div class="col-lg-4 col-md-4 text-center">
                            <div class="single-banner">
                                <a href="#">
                                    <img src="<?php echo e(URL::to('public/frontent/images/1_3.jpg')); ?>" alt="Li's Static Banner">
                                </a>
                            </div>
                        </div>
                        <!-- Single Banner Area End Here -->
                        <!-- Begin Single Banner Area -->
                        <div class="col-lg-4 col-md-4 text-center pt-xs-30">
                            <div class="single-banner">
                                <a href="#">
                                    <img src="<?php echo e(URL::to('public/frontent/images/1_4.jpg')); ?>" alt="Li's Static Banner">
                                </a>
                            </div>
                        </div>
                        <!-- Single Banner Area End Here -->
                        <!-- Begin Single Banner Area -->
                        <div class="col-lg-4 col-md-4 text-center pt-xs-30">
                            <div class="single-banner">
                                <a href="#">
                                    <img src="<?php echo e(URL::to('public/frontent/images/1_5.jpg')); ?>" alt="Li's Static Banner">
                                </a>
                            </div>
                        </div>
                        
                        <!-- Single Banner Area End Here -->
                    </div>
                </div>
            </div>
    <footer id="footer"><!--Footer-->
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="companyinfo">
                            <h2><span>e</span>-shopper</h2>
                            
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="<?php echo e(URL::to('public/frontent/images/samsung.jpg')); ?>" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                
                                <h2>20-11-2020</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="<?php echo e(URL::to('public/frontent/images/iphone.jpg')); ?>" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                
                                <h2>20-11-2020</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="<?php echo e(URL::to('public/frontent/images/oppo.png')); ?>" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <h2>20-11-2020</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="<?php echo e(URL::to('public/frontent/images/asus.png')); ?>" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                
                                <h2>20-11-2020</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="address">
                            <img src="<?php echo e(URL::to('public/frontent/images/map.png')); ?>" alt="" />
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer-widget">
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Dịch vụ</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Trợ giúp trực tuyến</a></li>
                                <li><a href="#">Liên hệ</a></li>
                                <li><a href="#">Tình trạng đặt hàng</a></li>
                                <li><a href="#">Câu hỏi thường gặp</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Danh sách</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Laptop</a></li>
                                <li><a href="#">Điện thoại</a></li>
                                <li><a href="#">Tivi</a></li>
                                <li><a href="#">loa</a></li>
                                <li><a href="#">Tai nghe</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Chính sách</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#"></a></li>
                                <li><a href="#">Điều khoản sử dụng</a></li>
                                <li><a href="#">Chính sách bảo mật</a></li>
                                <li><a href="#">Chính sách hoàn lại tiền</a></li>
                                <li><a href="#">Thanh toán</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Thông tin Shope</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Thông tin website</a></li>
                                <li><a href="#">Vị trí cửa hàng</a></li>
                                <li><a href="#">Bản quyền</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-3 col-sm-offset-1">
                        <div class="single-widget">
                            <h2>About Shopper</h2>
                            <form action="#" class="searchform">
                                <input type="text" placeholder="Email của bạn" />
                                <button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
                                
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <p class="pull-left">E-SHOPPE thế giới mua sắm của tất cả mọi người !!!</p>
                    <p class="pull-right">Thiết kế bởi Lê Thị Liên-DHBKHN <span></p>
                </div>
            </div>
        </div>
        
    </footer><!--/Footer-->
    

  
    <script src="<?php echo e(asset('public/frontent/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontent/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontent/js/jquery.scrollUp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontent/js/price-range.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontent/js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontent/js/main.js')); ?>"></script>

        <script src="js/vendor/jquery-1.12.4.min.js"></script>
        <script src="js/vendor/popper.min.js"></script>
        <script src="js/ajax-mail.js"></script>
        <script src="js/jquery.meanmenu.min.js"></script>
        <script src="js/wow.min.js"></script>->
        <script src="js/slick.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/isotope.pkgd.min.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/jquery.mixitup.min.js"></script>
        <script src="js/jquery.countdown.min.js"></script>
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/waypoints.min.js"></script>
        <script src="js/jquery.barrating.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/venobox.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/scrollUp.min.js"></script>
</body>
</html><?php /**PATH D:\xampp\htdocs\shopbanhang\resources\views/welcome.blade.php ENDPATH**/ ?>