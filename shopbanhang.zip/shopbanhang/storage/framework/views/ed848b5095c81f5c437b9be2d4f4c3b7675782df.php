<?php $__env->startSection('content'); ?>

<section id="cart_items">
		<div class="container">
			
			<div class="review-payment">
				<h2>Cảm ơn bạn đã đặt hàng, chúng tôi sẽ liên hệ với bạn sớm nhất</h2>
			</div>
		</div>
	</section> <!--/#cart_items-->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopbanhang\resources\views/pages/checkout/handcash.blade.php ENDPATH**/ ?>